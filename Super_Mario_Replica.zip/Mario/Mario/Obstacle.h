#ifndef Obstacle_h
#define Obstacle_h

#include "GlobalVariables.h"
#include "Character.h"


class Obstacle {
private:
    float obsX;
    float obsY;
    float obsWidth;
    float obsHeight;
    float colorR; // Red component of color (0.0 to 1.0)
    float colorG; // Green component of color (0.0 to 1.0)
    float colorB; // Blue component of color (0.0 to 1.0)


public:
    Obstacle(float xPos, float yPos, float width, float height, float red, float green, float blue)
        : obsX(xPos), obsY(yPos), obsWidth(width), obsHeight(height), colorR(red), colorG(green), colorB(blue) {}

    void draw() const {
        glColor3f(colorR, colorG, colorB);

        glBegin(GL_QUADS);
        glVertex2f(obsX, obsY);
        glVertex2f(obsX + obsWidth, obsY);
        glVertex2f(obsX + obsWidth, obsY + obsHeight);
        glVertex2f(obsX, obsY + obsHeight);
        glEnd();
    }
    
    // Add methods to set and get color components
        void setColor(float red, float green, float blue) {
            colorR = red;
            colorG = green;
            colorB = blue;
        }

    bool checkCollision(Character character) const {
        float charLeft = character.getX();
        float charRight = character.getX() + character.getWidth();
        float charTop = character.getY() + character.getHeight();
        float charBottom = character.getY();

        float obstacleLeft = getX();
        float obstacleRight = getX() + getWidth();
        float obstacleTop = getY() + getHeight();
        float obstacleBottom = getY();

        // Check if the character collides with the obstacle
        if (charRight < obstacleLeft || charLeft > obstacleRight || charTop < obstacleBottom || charBottom > obstacleTop) {
            // Bounding boxes do not intersect, so no collision
            return false;
        } else {
            // Bounding boxes intersect, so collision
            return true;
        }

    }
    
    

    float getX() const { return obsX; }
    float getY() const { return obsY; }
    float getWidth() const { return obsWidth; }
    float getHeight() const { return obsHeight; }
};


#endif
