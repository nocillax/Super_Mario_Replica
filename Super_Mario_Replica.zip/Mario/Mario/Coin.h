#ifndef Coin_h
#define Coin_h

#include "GlobalVariables.h"
#include "Character.h"



class Coin {
private:
    float x;      // X-coordinate of the coin's center
    float y;      // Y-coordinate of the coin's center
    float radius; // Radius of the coin (considering it's a circle)
    float red;    // Red component of the coin's color
    float green;  // Green component of the coin's color
    float blue;   // Blue component of the coin's color
    
public:
    // Constructor to initialize the coin
    Coin(float x, float y, float radius, float red, float green, float blue)
    : x(x), y(y), radius(radius), red(red), green(green), blue(blue) {}
    
    bool isActive = true;
    bool isCollected = false;
    bool collectedCoinFlag;
    bool isCollidingWithCoin = false; // Add a flag to track if character is colliding with a coin
    
    // Getters for the coin properties
    float getX() const { return x; }
    float getY() const { return y; }
    float getRadius() const { return radius; }
    float getRed() const { return red; }
    float getGreen() const { return green; }
    float getBlue() const { return blue; }
    
    // Setters for the coin properties
    void setX(float newX) { x = newX; }
    void setY(float newY) { y = newY; }
    void setRadius(float newRadius) { radius = newRadius; }
    void setRed(float newRed) { red = newRed; }
    void setGreen(float newGreen) { green = newGreen; }
    void setBlue(float newBlue) { blue = newBlue; }
    
    
    // Function to draw the coin using GLUT functions
    void draw() const{
        
        if(isActive && !isCollected) {
            
            //outer circle
            GLfloat a= x;
            GLfloat b= y;
            GLfloat radius = 20.0f;
            int triangleAmount = 100; //# of lines used to draw circle

            GLfloat twicePi = 2.0f * PI;

            glColor3ub(255,215,0);
            glBegin(GL_TRIANGLE_FAN);
            glVertex2f(a, b); // center of circle
            for(int i = 0; i <= triangleAmount; i++)
            {
                glVertex2f( a + (radius * cos(i *  twicePi / triangleAmount)),
                            b + (radius * sin(i * twicePi / triangleAmount)) );
            }
            glEnd();
            
            //inner black line
            glLineWidth(2.0f);
            GLfloat x1=x;
            GLfloat y1 =y;
            GLfloat radius1 =(radius/2);
            int lineAmount = 100; //# of triangles used to draw circle
            GLfloat twicePi1 = 2.0f * PI;

            glColor3f(0.0f, 0.0f, 0.0f);
            glBegin(GL_LINE_LOOP);
            for(int i = 0; i <= lineAmount; i++)
            {
                glVertex2f(
                    x1 + (radius1 * cos(i *  twicePi1 / lineAmount)),
                    y1 + (radius1* sin(i * twicePi1 / lineAmount))
                );
            }
            glEnd();

            //inner circle
            glLineWidth(2.0f);
            GLfloat x2=x;
            GLfloat y2=y;
            GLfloat radius2 = radius;
            int lineAmount2 = 100; //# of triangles used to draw circle
            GLfloat twicePi2 = 2.0f * PI;

            glColor3f(0.0f, 0.0f, 0.0f);
            glBegin(GL_LINE_LOOP);
            for(int i = 0; i <= lineAmount2; i++)
            {
                glVertex2f(
                    x2 + (radius2 * cos(i *  twicePi2 / lineAmount2)),
                    y2 + (radius* sin(i * twicePi2 / lineAmount2))
                );
            }
            glEnd();

            glPopMatrix();
        }
    }

    // Function to check collision with the coin
        bool checkCollision(Character character) const {
            float charLeft = character.getX();
                float charRight = character.getX() + character.getWidth();
                float charTop = character.getY() + character.getHeight();
                float charBottom = character.getY();

                float coinLeft = getX() - getRadius();
                float coinRight = getX() + getRadius();
                float coinTop = getY() + getRadius();
                float coinBottom = getY() - getRadius();

                // Check if the bounding boxes intersect
                if (charRight < coinLeft || charLeft > coinRight || charTop < coinBottom || charBottom > coinTop) {
                    // Bounding boxes do not intersect, so no collision
                    return false;
                } else {
                    // Bounding boxes intersect, so collision
                    return true;
                }
            }
    
    // Function to collect the coin and update the score
    void collectCoin() {
        if (isActive) {
            isActive = false; // Set isActive to false for the collected coin
            score++;
            collectedCoinFlag = true;
            //isCollidingWithCoin = true; // Set the flag to true to prevent further collisions
            isCollected = true; // Set the flag to indicate the coin is collected
        }
    }
    
    // Function to check collision between character and coins
    void checkCoinCollision(Character character) {
        // Reset the flag before checking collisions with coins
            //isCollidingWithCoin = false;
        
            if (checkCollision(character)) {
                //std::cout << "Collision detected with coin at index " << i << std::endl;
                collectCoin();
            }
    }
    
};


#endif
