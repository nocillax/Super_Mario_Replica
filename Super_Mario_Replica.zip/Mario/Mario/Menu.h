#ifndef Menu_h
#define Menu_h

#include "GlobalVariables.h"

// Function to Use SPACE BAR
void keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 32: // Space
        isStage1 = true;
        glutPostRedisplay(); // Mark the window for a redraw
        break;

    case 50: // Numpad 2 key
        isStage2 = true;
        glutPostRedisplay();
        break;
            
    case 51: // Esc key
        isStage3 = true;
        glutPostRedisplay();
        break;
            
            
    }
}

void drawText(const std::string& text, int x, int y, void* font, float r, float g, float b) {
    glColor3f(r, g, b);
    glRasterPos2i(x, y);

    for (char c : text) {
        glutBitmapCharacter(font, c);
    }
}

void menu(){
    glBegin(GL_QUADS);
    glColor3f(0.576f, 0.627f, 0.835f);
    glVertex2f(500.0f, 483.0f);
    glVertex2f(500.0f, 535.0f);
    glVertex2f(785.0f, 535.0f);
    glVertex2f(785.0f, 483.0f);
    glEnd();
    
    glBegin(GL_LINE_LOOP);
    glLineWidth(3.0f);
    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(500.0f, 483.0f);
    glVertex2f(500.0f, 535.0f);
    glVertex2f(785.0f, 535.0f);
    glVertex2f(785.0f, 483.0f);
    glEnd();
    
    drawText("SUPER MARIO", 560, 500, GLUT_BITMAP_TIMES_ROMAN_24, 1.0f, 1.0f, 1.0f);
    drawText("START NEW GAME", 532, 380, GLUT_BITMAP_TIMES_ROMAN_24, 1.0f, 1.0f, 1.0f);
    drawText("_Press Space to Start New Game_", 463, 100, GLUT_BITMAP_TIMES_ROMAN_24, 1.0f, 1.0f, 1.0f);
    
    drawText("STAGE 02", 580, 290, GLUT_BITMAP_TIMES_ROMAN_24, 1.0f, 1.0f, 1.0f);
    drawText("_Press 2 to Start Next Stage_", 490, 260, GLUT_BITMAP_TIMES_ROMAN_24, 1.0f, 1.0f, 1.0f);

    drawText("STAGE 03", 580, 210, GLUT_BITMAP_TIMES_ROMAN_24, 1.0f, 1.0f, 1.0f);
    drawText("_Press 3 to Start Next Stage_", 490, 180, GLUT_BITMAP_TIMES_ROMAN_24, 1.0f, 1.0f, 1.0f);


}


#endif
