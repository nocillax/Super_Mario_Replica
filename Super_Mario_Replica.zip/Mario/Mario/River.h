#ifndef River_h
#define River_h

#include "GlobalVariables.h"
#include "Character.h"



class River {
private:
    float rivX;
    float rivY;
    float rivWidth;
    float rivHeight;
    float colorR; // Red component of color (0.0 to 1.0)
    float colorG; // Green component of color (0.0 to 1.0)
    float colorB; // Blue component of color (0.0 to 1.0)

public:
    River(float xPos, float yPos, float width, float height, float red, float green, float blue)
        : rivX(xPos), rivY(yPos), rivWidth(width), rivHeight(height), colorR(red), colorG(green), colorB(blue) {}

    void draw() const {
        glColor3f(colorR, colorG, colorB);

        glBegin(GL_QUADS);
        glVertex2f(rivX, rivY);
        glVertex2f(rivX + rivWidth, rivY);
        glVertex2f(rivX + rivWidth, rivY + rivHeight);
        glVertex2f(rivX, rivY + rivHeight);
        glEnd();
    }
    
    // Add methods to set and get color components
        void setColor(float red, float green, float blue) {
            colorR = red;
            colorG = green;
            colorB = blue;
        }
    
    // Function to check if there is a collision between the character and the river
    bool checkRiverCollision(Character character) const{
        // Check if the character's position is within the river area
        if (character.getY() <= (rivY + rivHeight) && character.getX()  >= rivX && character.getX() <= (rivX + rivWidth-character.getSize())){
            return true;
        }
        else {
            
            return false; // No collision
        }
    }

};

#endif /* River_h */
